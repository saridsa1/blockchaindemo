# Welcome to Novartis block chain initiative!

This is a sample implementation of block chain within Novartis